<?php
	$s = 0;
	/* multi-line
	commenr */
	$i = 0;
	$b = 25 * 2 + 10;
	// single line comment
	while($i < 100){
		$s = $s + $i;
		$i = $i + 1;
	}
	if($i > 10){
		print($i);
	}
?>